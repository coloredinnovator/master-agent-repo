export type GrantStatus =
  | 'draft'
  | 'in_progress'
  | 'ready_for_review'
  | 'submitted'
  | 'approved'
  | 'rejected';

export interface NarrativeSection {
  description?: string;
  spiritual?: string;
  goals?: string;
}

export interface FinancialsSection {
  budget?: number;
  fiscalStart?: string;
  fiscalEnd?: string;
  ein?: string;
}

export interface DocumentsSection {
  form990?: string;
  irsLetter?: string;
  budgetFile?: string;
  impactReport?: string;
}

export interface GrantApplication {
  id: string;
  funder: string;
  dueDate: string;
  status: GrantStatus;
  narrative: NarrativeSection;
  financials: FinancialsSection;
  documents: DocumentsSection;
  createdAt: string;
}