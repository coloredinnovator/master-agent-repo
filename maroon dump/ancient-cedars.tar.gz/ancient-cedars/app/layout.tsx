import './globals.css';
import Nav from '@/components/Nav';
import WaterEffect from '@/components/WaterEffect';
import React from 'react';

export const metadata = {
  title: 'Ancient Cedars',
  description: 'A storytelling and grant platform rooted in the Pacific Northwest.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="relative min-h-screen overflow-x-hidden bg-[var(--background)] text-[var(--foreground)]">
        <div className="relative z-10 flex min-h-screen flex-col">
          {/* Primary navigation */}
          <Nav />
          {/* Main content */}
          <main className="flex-1" data-testid="page-content">
            {children}
          </main>
        </div>
        {/* Animated background effect */}
        <WaterEffect />
      </body>
    </html>
  );
}