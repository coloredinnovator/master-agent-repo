"use client";
import React from 'react';
import { motion } from 'framer-motion';

export default function StoryPage() {
  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <motion.h2
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="mb-4 text-4xl font-semibold"
      >
        Our Stories
      </motion.h2>
      <p className="mb-8 text-lg opacity-80">
        This is a placeholder page for storytelling content. In a complete implementation
        you would dynamically render scenes derived from your curated narratives about
        cedar, creation and community. Each section could include imagery, audio and
        interactive prompts for reflection.
      </p>
      {/* Example of a story card */}
      <div className="space-y-6">
        <div className="rounded-xl border border-white/10 bg-white/5 p-6 shadow">
          <h3 className="text-2xl font-medium">The Gift of Cedar</h3>
          <p className="mt-2 text-sm opacity-80">
            Discover how cedar has sheltered and clothed our people for generations. Learn
            about traditional weaving techniques and the spiritual significance of the
            ancient tree.
          </p>
        </div>
        <div className="rounded-xl border border-white/10 bg-white/5 p-6 shadow">
          <h3 className="text-2xl font-medium">Reflections on Water</h3>
          <p className="mt-2 text-sm opacity-80">
            Explore how water and cedar intertwine to create ecosystems of abundance.
            Reflect on the role of rivers, lakes and rain in sustaining life on the
            Northwest coast.
          </p>
        </div>
      </div>
    </div>
  );
}