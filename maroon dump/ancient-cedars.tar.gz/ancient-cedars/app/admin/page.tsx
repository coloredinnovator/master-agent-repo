"use client";
import React from 'react';
import Link from 'next/link';

export default function AdminPage() {
  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <h2 className="mb-4 text-4xl font-semibold">Admin Dashboard</h2>
      <p className="mb-8 text-lg opacity-80">
        Manage grants and content from here. This page is a starting point for the
        administrative backend. Implement authentication and routing guards to protect
        this area in production.
      </p>
      <div className="grid gap-6 sm:grid-cols-2">
        <div className="rounded-xl border border-white/10 bg-white/5 p-6 shadow">
          <h3 className="text-2xl font-medium">Grant Applications</h3>
          <p className="mt-2 text-sm opacity-80">
            View and manage grant submissions. Start a new application or review
            existing drafts.
          </p>
          <Link href="/admin/grants" className="mt-4 inline-block text-sm text-blue-200 hover:underline">
            Go to grants
          </Link>
        </div>
        <div className="rounded-xl border border-white/10 bg-white/5 p-6 shadow">
          <h3 className="text-2xl font-medium">Answer Library</h3>
          <p className="mt-2 text-sm opacity-80">
            Build a reusable library of narrative responses for common grant questions.
            Auto‑fill applications and enforce consistency.
          </p>
          <Link href="/admin/library" className="mt-4 inline-block text-sm text-blue-200 hover:underline">
            Go to library
          </Link>
        </div>
      </div>
    </div>
  );
}