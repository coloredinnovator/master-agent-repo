"use client";
import React from 'react';
import Link from 'next/link';

export default function GrantsList() {
  // In a real implementation this data would be fetched from Firestore.
  const grants = [
    { id: 'wayfarer-pathways', title: 'Wayfarer Pathways', status: 'Draft', due: '2026-03-31' },
    { id: 'general-operating', title: 'General Operating', status: 'In Progress', due: '2026-05-15' },
  ];
  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <h2 className="mb-4 text-3xl font-semibold">Grant Applications</h2>
      <p className="mb-8 text-sm opacity-70">Select a grant to continue editing or reviewing.</p>
      <div className="space-y-4">
        {grants.map((grant) => (
          <Link
            key={grant.id}
            href={`/admin/grants/${grant.id}`}
            className="block rounded-xl border border-white/10 bg-white/5 p-4 hover:bg-white/10"
          >
            <div className="flex justify-between">
              <span className="font-medium">{grant.title}</span>
              <span className="text-sm">{grant.status}</span>
            </div>
            <div className="mt-1 text-xs opacity-70">Due {grant.due}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}