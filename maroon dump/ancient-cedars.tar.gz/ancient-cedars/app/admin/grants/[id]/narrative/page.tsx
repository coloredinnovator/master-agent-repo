"use client";
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function GrantNarrative({ params }: { params: { id: string } }) {
  const { id } = params;
  const router = useRouter();
  const [text, setText] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Save `text` to Firestore here. In this scaffold we simply log it.
    console.log('Narrative submitted', { id, text });
    router.push(`/admin/grants/${id}`);
  };

  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <button onClick={() => router.back()} className="mb-4 text-sm text-blue-200 hover:underline">
        ← Back to grant
      </button>
      <h2 className="mb-4 text-3xl font-semibold">Narrative</h2>
      <p className="mb-6 text-sm opacity-70">
        Craft a concise (300‑word) description of your organisation, its goals and
        how it reflects spiritual values in action. You can save your progress
        and return later.
      </p>
      <form onSubmit={handleSubmit} className="space-y-4">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="w-full min-h-[200px] rounded-lg border border-white/20 bg-white/5 p-3 text-sm placeholder-white/50 focus:outline-none"
          maxLength={3000}
          placeholder="Write your narrative..."
        />
        <div className="flex justify-between">
          <span className="text-xs opacity-70">
            {text.length} / 3000 characters
          </span>
          <button
            type="submit"
            className="rounded-lg bg-blue-500 px-4 py-2 text-sm text-white hover:bg-blue-600"
          >
            Save
          </button>
        </div>
      </form>
    </div>
  );
}