"use client";
import React from 'react';
import { useRouter } from 'next/navigation';
import { Upload } from '@/components/Upload';

export default function GrantDocuments({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { id } = params;
  const handleFile = (file: File) => {
    // In a real app, upload the file to Firebase Storage and store its
    // reference in Firestore. Here we simply log it for demonstration.
    console.log('Selected file for', id, file.name);
  };
  return (
    <div className="mx-auto max-w-3xl px-6 py-16">
      <button onClick={() => router.back()} className="mb-4 text-sm text-blue-200 hover:underline">
        ← Back to grant
      </button>
      <h2 className="mb-4 text-3xl font-semibold">Documents</h2>
      <p className="mb-6 text-sm opacity-70">
        Upload required documents. You can replace files later if needed. Accepted
        formats: PDF, DOCX, XLSX, ODT.
      </p>
      <div className="space-y-6">
        <Upload label="Form 990" onFileSelect={handleFile} />
        <Upload label="501(c)(3) Determination Letter" onFileSelect={handleFile} />
        <Upload label="Organisation Budget" onFileSelect={handleFile} />
        <Upload label="Impact Report (optional)" onFileSelect={handleFile} />
      </div>
    </div>
  );
}