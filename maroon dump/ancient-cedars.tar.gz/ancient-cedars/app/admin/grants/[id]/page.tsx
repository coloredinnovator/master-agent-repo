"use client";
import React from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function GrantDetail({ params }: { params: { id: string } }) {
  const router = useRouter();
  const { id } = params;
  // Placeholder grant data. In a real app this would come from Firestore.
  const grant = {
    id,
    title: id.replace(/-/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
    status: 'Draft',
    due: '2026-03-31',
  };
  return (
    <div className="mx-auto max-w-4xl px-6 py-16">
      <button onClick={() => router.back()} className="mb-4 text-sm text-blue-200 hover:underline">
        ← Back to grants
      </button>
      <h2 className="mb-2 text-3xl font-semibold">{grant.title}</h2>
      <p className="mb-4 text-sm opacity-70">Status: {grant.status} · Due {grant.due}</p>
      <div className="grid gap-6 sm:grid-cols-2">
        <div className="rounded-xl border border-white/10 bg-white/5 p-6 shadow">
          <h3 className="text-xl font-medium">Narrative</h3>
          <p className="mt-2 text-xs opacity-70">Compose or edit the 300‑word story describing your organisation, goals and spiritual framing.</p>
          <Link href={`/admin/grants/${id}/narrative`} className="mt-4 inline-block text-sm text-blue-200 hover:underline">
            Go to narrative
          </Link>
        </div>
        <div className="rounded-xl border border-white/10 bg-white/5 p-6 shadow">
          <h3 className="text-xl font-medium">Documents</h3>
          <p className="mt-2 text-xs opacity-70">Upload your 990, 501(c)(3) letter, budgets and other supporting files.</p>
          <Link href={`/admin/grants/${id}/documents`} className="mt-4 inline-block text-sm text-blue-200 hover:underline">
            Go to documents
          </Link>
        </div>
      </div>
    </div>
  );
}