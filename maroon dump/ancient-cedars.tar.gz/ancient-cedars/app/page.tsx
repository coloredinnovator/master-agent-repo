"use client";
import { motion } from 'framer-motion';
import Link from 'next/link';
import React from 'react';

export default function Home() {
  return (
    <section className="relative flex min-h-[calc(100vh-4rem)] flex-col items-center justify-center overflow-hidden px-6 text-center">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.2 }}
        className="z-10 mb-6 text-5xl font-light sm:text-6xl"
      >
        Ancient Cedars
      </motion.h1>
      <motion.p
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.6, delay: 0.3 }}
        className="z-10 max-w-xl text-lg leading-relaxed opacity-80 sm:text-xl"
      >
        Where culture, creation, and divine goodness intersect. Explore stories rooted
        in cedar and experience a new way to engage with our heritage.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1.6, delay: 0.6 }}
        className="z-10 mt-10 flex space-x-4"
      >
        <Link
          href="/story"
          className="rounded-xl bg-white/10 px-6 py-3 text-sm font-medium text-white shadow hover:bg-white/20"
        >
          Enter the story
        </Link>
        <Link
          href="/admin"
          className="rounded-xl bg-white/10 px-6 py-3 text-sm font-medium text-white shadow hover:bg-white/20"
        >
          Admin
        </Link>
      </motion.div>
    </section>
  );
}