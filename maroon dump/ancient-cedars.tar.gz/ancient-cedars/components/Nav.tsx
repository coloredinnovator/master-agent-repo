"use client";
import Link from 'next/link';
import React from 'react';

/**
 * A simple navigation bar. In a real application this component would
 * include links to your storytelling sections, admin dashboard and
 * authentication actions. It is intentionally minimal here and can be
 * extended as your project evolves.
 */
export default function Nav() {
  return (
    <nav className="flex items-center justify-between px-6 py-4">
      <Link href="/" className="text-xl font-semibold">
        Ancient Cedars
      </Link>
      <div className="space-x-4 text-sm">
        <Link href="/story">Story</Link>
        <Link href="/admin">Admin</Link>
      </div>
    </nav>
  );
}