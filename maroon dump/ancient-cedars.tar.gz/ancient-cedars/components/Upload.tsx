"use client";
import React, { useRef, useState } from 'react';

interface UploadProps {
  label: string;
  onFileSelect?: (file: File) => void;
}

/**
 * Upload provides a minimal file input with custom styling. Pass a label
 * describing the expected document (e.g. "Form 990") and optionally handle
 * the selected file with the `onFileSelect` callback.
 */
export function Upload({ label, onFileSelect }: UploadProps) {
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      onFileSelect?.(file);
    }
  };

  return (
    <div className="rounded-xl border border-white/10 bg-white/5 p-4 shadow">
      <p className="mb-2 text-sm font-medium">{label}</p>
      <input
        ref={inputRef}
        type="file"
        onChange={handleFileChange}
        className="w-full cursor-pointer rounded-md border border-white/20 bg-transparent p-2 text-sm"
      />
      {fileName && (
        <p className="mt-2 text-xs opacity-70">Selected: {fileName}</p>
      )}
    </div>
  );
}