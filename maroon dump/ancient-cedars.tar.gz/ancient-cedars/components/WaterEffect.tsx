"use client";
import React from 'react';

/**
 * WaterEffect renders a subtle animated wave at the bottom of the screen.
 * The animation is controlled via a custom Tailwind keyframe defined in
 * tailwind.config.js (see the `wave` keyframes and `animate-wave` utility).
 *
 * This component is non‑intrusive and meant to add a sense of calm motion
 * behind your content. It should be layered beneath primary UI elements.
 */
export default function WaterEffect() {
  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-0 z-0 overflow-hidden">
      {/* First wave: subtle highlight */}
      <div
        className="absolute bottom-0 left-0 h-24 w-[200%] animate-wave"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(255,255,255,0.1), rgba(255,255,255,0))',
        }}
      />
      {/* Second wave: deeper shadow */}
      <div
        className="absolute bottom-0 left-0 h-16 w-[200%] animate-wave"
        style={{
          backgroundImage:
            'linear-gradient(to right, rgba(255,255,255,0.05), rgba(255,255,255,0))',
          animationDelay: '4s',
        }}
      />
    </div>
  );
}