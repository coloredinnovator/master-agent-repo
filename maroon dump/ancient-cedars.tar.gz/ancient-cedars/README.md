# Ancient Cedars

Ancient Cedars is a storytelling and grant‑management platform built for the Pacific Northwest community.  
It combines a cinematic public experience with a powerful administrative backend for managing funding applications and narrative content.

## Repository structure

```
ancient-cedars/
├── app/                 # Next.js app directory (public facing and admin)
│   ├── layout.tsx       # Root layout with global providers
│   ├── globals.css      # Global Tailwind styles
│   ├── page.tsx         # Public landing page
│   ├── story/           # Public storytelling pages
│   └── admin/           # Admin dashboard pages (grant system)
│       └── grants/
├── components/          # Shared React components
│   ├── WaterEffect.tsx  # Custom water animation
│   └── Nav.tsx          # Example navigation component (placeholder)
├── services/            # Firebase initialisation and helpers
│   └── firebase.ts      # Firebase client configuration
├── types/               # TypeScript models for Firestore
│   └── grants.ts        # Grant application interface definitions
├── firebase/            # Firebase configuration and security rules
│   ├── firestore.rules  # Firestore security rules (starter)
│   └── storage.rules    # Cloud Storage rules (starter)
├── public/              # Static assets (logos, icons, etc.)
├── tailwind.config.js   # Tailwind CSS configuration
├── postcss.config.js    # PostCSS configuration
├── tsconfig.json        # TypeScript configuration
├── package.json         # NPM package definitions and scripts
├── .env.example         # Environment variables template
└── next.config.js       # Next.js configuration
```

## Getting started

1. **Install dependencies**

   Make sure you have Node.js (v18 or later) installed. Then run:

   ```bash
   npm install
   ```

2. **Set up Firebase**

   Create a Firebase project in the [Firebase Console](https://console.firebase.google.com/). Enable **Authentication**, **Firestore** and **Storage**.  
   Copy your Firebase configuration keys into a new `.env.local` file. Use `.env.example` as a template:

   ```env
   NEXT_PUBLIC_FIREBASE_API_KEY=<your api key>
   NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=<your auth domain>
   NEXT_PUBLIC_FIREBASE_PROJECT_ID=<your project id>
   NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=<your storage bucket>
   NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=<your messaging sender id>
   NEXT_PUBLIC_FIREBASE_APP_ID=<your app id>
   ```

3. **Run the development server**

   ```bash
   npm run dev
   ```

   Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

4. **Deploy to Firebase Hosting**

   Install the Firebase CLI if you haven’t already:

   ```bash
   npm install -g firebase-tools
   ```

   Log in and initialise your Firebase project in the root of this repository:

   ```bash
   firebase login
   firebase init
   ```

   During initialisation, select **Hosting**, **Firestore** and **Storage**, then specify the `ancient-cedars` folder as your public directory. Configure it as a Single Page App and set up the provided `firebase` rules. When ready to deploy, run:

   ```bash
   npm run build
   firebase deploy
   ```

## Design direction

The user experience is intentionally calm and cinematic.  
Throughout the app you should use rich imagery of the Pacific Northwest, muted colour palettes, and spacious layouts.  
The **water effect** component demonstrates how subtle motion can add life without distracting from the content.

## Notes

* This project uses **Next.js 13+** with the `/app` directory for layout and routing.  
* Tailwind CSS is used for styling, with custom animation defined in `WaterEffect.tsx`.  
* Firestore data models live in `types/`; adjust these interfaces as the data model evolves.  
* The administrative backend is a scaffold – customise the pages under `app/admin` to suit your grant workflow.  
* Security rules are permissive for development. Harden them before production.
